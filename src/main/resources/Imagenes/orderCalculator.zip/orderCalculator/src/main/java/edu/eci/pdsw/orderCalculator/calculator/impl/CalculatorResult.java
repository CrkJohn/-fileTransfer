package edu.eci.pdsw.orderCalculator.calculator.impl;

public enum CalculatorResult {
	CORRECT, INCORRECT
}
